Fabcheck demo sample. A synthetic board drawn by tools/make_sample.py; not a real or client design.
