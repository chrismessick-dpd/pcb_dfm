Fabcheck demo sample board.
A scrubbed copy of a Dovetail board, with planted problems for the demo.
Made by tools/make_sample.py in the pcb_dfm repository.
