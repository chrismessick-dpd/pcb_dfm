Fabcheck demo flex: DT-1045 Sensor Flex, rev A.
Made up for the Dovetail Signoff demo (Acme Climate Smart Thermostat). Not a real design.
Made by tools/make_flex_demo.py in the pcb_dfm repository.
