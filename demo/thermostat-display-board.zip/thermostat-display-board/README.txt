Fabcheck demo board: DT-1043 Display & Sensor Board, rev A.
Made up for the Dovetail Signoff demo (Acme Climate Smart Thermostat). Not a real design.
Made by tools/make_demo_boards.py in the pcb_dfm repository.
